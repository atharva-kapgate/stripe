import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({ providedIn: 'root' })
export class StripeService {
  private http = inject(HttpClient);

  /**
   * Creates a Stripe Checkout session and returns the hosted payment page URL.
   * @param amount Amount in paise (e.g. ₹100 = 10000)
   * @param currency Currency code (default: 'inr')
   */
  createCheckoutSession(amount: number, currency: string = 'inr') {
    return this.http.post<{ url: string }>(
      'https://localhost:7252/api/Payments/create-session',
      { amount, currency }
    );
  }

  /**
   * Redirects the user to the Stripe-hosted payment page.
   * @param amount Amount in paise
   */
  async redirectToCheckout(amount: number) {
    const res = await this.createCheckoutSession(amount).toPromise();
    if (res?.url) {
      window.location.href = res.url;
    } else {
      console.error('Stripe Checkout URL not received');
    }
  }
}
