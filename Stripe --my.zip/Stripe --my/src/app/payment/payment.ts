import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StripeService } from '../services/stripe-service';

@Component({
  selector: 'payment',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './payment.html',
  styleUrls: ['./payment.scss']
})
export class Payment {
  private stripeService = inject(StripeService);
  status = '';
  loading = false;

  async pay() {
    this.loading = true;
    this.status = 'Redirecting to Stripe Checkout...';

    try {
      await this.stripeService.redirectToCheckout(10000); // ₹100
    } catch (error) {
      console.error('Stripe redirect failed:', error);
      this.status = '❌ Failed to redirect to Stripe.';
      this.loading = false;
    }
  }
}
