import { Routes } from '@angular/router';
import { Payment } from './payment/payment';

export const routes: Routes = [
    { path: '', component: Payment }
];
